function startAimbot() {
    // Tìm mã vân tay của hàm Ngắm bắn (AOB Scan)
    h5gg.clearResults();
    h5gg.searchNumber('000080D2C0035FD6', 'I8', '0x0', '0x200000000');
    let res = h5gg.getResults(1);
    if (res.length > 0) {
        h5gg.editNumber(res[0].address, '1', 'I8'); 
        alert("Đã tìm thấy mã và kích hoạt Aimbot!");
    } else {
        alert("Không tìm thấy mã Gen, hãy thử lại trong trận!");
    }
}
